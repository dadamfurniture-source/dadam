# Vibe Cabinet AI Agent

AI 기반 맞춤 가구 설계 및 자동 자재 산출 솔루션

## 🏗️ 아키텍처

```
┌─────────────────────────────────────────────────────────────┐
│                    Cloud (Vercel / Railway)                 │
├─────────────────────────────────────────────────────────────┤
│  Frontend (Next.js 14)          │  Backend (FastAPI)        │
│  ├─ 치수 입력 폼                 │  ├─ /api/chat            │
│  ├─ 대화형 AI 채팅 UI            │  ├─ /api/calculate       │
│  ├─ 실시간 도면 프리뷰           │  ├─ /api/design          │
│  └─ 모듈 시각화                 │  └─ WebSocket 지원        │
├─────────────────────────────────────────────────────────────┤
│                    AI Agent Layer                           │
│  ├─ Claude 3.5 Sonnet (한국어 최적)                          │
│  ├─ Tool Calling (설계 계산, DB 조회, 도면 생성)              │
│  └─ 세션 관리 (Redis)                                       │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 빠른 시작

### 1. 환경 설정

```bash
# 저장소 클론
cd dadam-ai-agent

# 환경 변수 설정
cp backend/.env.example backend/.env
# .env 파일에 ANTHROPIC_API_KEY 설정
```

### 2. Docker로 실행

```bash
# 전체 스택 실행
docker-compose up -d

# 로그 확인
docker-compose logs -f
```

### 3. 개별 실행

**백엔드:**
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
# http://localhost:8000
```

**프론트엔드:**
```bash
cd frontend
npm install
npm run dev
# http://localhost:3000
```

## 📡 API 엔드포인트

### 채팅 API
- `POST /api/chat` - AI 채팅
- `GET /api/chat/session/{id}` - 세션 조회
- `DELETE /api/chat/session/{id}` - 세션 초기화

### 설계 API
- `GET /api/design/categories` - 가구 카테고리 목록
- `GET /api/design/fridge/models` - 냉장고 모델 목록
- `POST /api/design/fridge/recommend` - 냉장고 추천
- `POST /api/design/fridge/layout` - 레이아웃 계산

### 계산 API
- `GET /api/calculate/distribute?total_space=3000` - 모듈 분배
- `GET /api/calculate/effective-space` - 유효 공간 계산
- `GET /api/calculate/door-width` - 도어 너비 계산

## 🤖 AI 에이전트 기능

### 도구 (Tools)
1. **calculate_modules** - 최적 모듈 분배 계산
2. **search_fridge** - 냉장고 모델 검색
3. **recommend_fridge** - 공간에 맞는 냉장고 추천
4. **calculate_fridge_layout** - 냉장고장 레이아웃 계산
5. **get_effective_space** - 유효 공간 계산

### 예시 대화
```
사용자: 3000mm에 LG 냉장고로 설계해줘

AI: 3000mm 공간에 적합한 냉장고를 찾았습니다!

추천 모델 TOP 3:
1. LG 500+300 세트
   - 크기: 1303 × 1850mm
   - 잔여 공간: 577mm
   - 키큰장 추가: 가능

어떤 모델로 진행하시겠어요?
```

## 📐 설계 규칙

### 도어 규격
- 최소: 350mm
- 최대: 600mm
- 목표: 450mm

### 잔여 공간
- 최적: 4~10mm
- 허용: 0~15mm

### 모듈 분배
- 도어수 / 2 = 2D 모듈 개수
- 나머지 = 1D 모듈 개수

## 🛠️ 기술 스택

### 백엔드
- Python 3.11
- FastAPI
- Anthropic Claude API
- Redis (세션)

### 프론트엔드
- Next.js 14 (App Router)
- React 18
- TailwindCSS
- TypeScript

### 인프라
- Docker
- Vercel / Railway
- Redis Cloud

## 📂 프로젝트 구조

```
dadam-ai-agent/
├── frontend/                    # Next.js 프론트엔드
│   ├── app/
│   │   ├── page.tsx            # 메인 페이지
│   │   └── globals.css
│   ├── components/
│   │   ├── ChatInterface.tsx   # AI 채팅 UI
│   │   ├── DimensionForm.tsx   # 치수 입력 폼
│   │   └── DesignPreview.tsx   # 도면 프리뷰
│   └── package.json
│
├── backend/                     # FastAPI 백엔드
│   ├── main.py                 # 서버 엔트리
│   ├── agents/
│   │   └── design_agent.py     # AI 에이전트
│   ├── tools/
│   │   ├── dimension_calc.py   # 치수 계산
│   │   ├── fridge_lookup.py    # 냉장고 조회
│   │   └── module_optimizer.py # 모듈 최적화
│   ├── routers/
│   │   ├── chat.py
│   │   ├── design.py
│   │   └── calculate.py
│   ├── data/
│   │   ├── fridge_data.py
│   │   └── constants.py
│   └── requirements.txt
│
├── docker-compose.yml
└── README.md
```

## 🔑 환경 변수

```env
# 필수
ANTHROPIC_API_KEY=your_api_key

# 선택
REDIS_URL=redis://localhost:6379
DEBUG=true
```

## 📝 라이선스

MIT License
